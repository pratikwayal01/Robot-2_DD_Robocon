Pixy2 README

This directory contains:

/releases - this directory contains binaries for various releases 

/scripts - this directory contains scripts for building pixy software modules.

/src/device - this directory contains code (firmware) that runs on the Pixy2 device.

/src/host - this directory contains code that runs on the host computer.
(Windows PC, Linux PC, Mac)

