script('..\data\blue_ball\', 'pixels1', .005, .90, 1.7);
script('..\data\green_swatch\', 'pixels1', .005, .90, 3.0);
script('..\data\pink_swatch\', 'pixels1', .005, .90, 4.0);
script('..\data\orange_ball\', 'pixels3', .005, .90, 1.0);
script('..\data\green_ball\', 'pixels2', .005, .90, 1.7);
script('..\data\hand\', 'pixels1', .005, .90, 0.5);

script4('..\data\blue_ball\', 'pixels1', .005, .90, 1.7, 0.05, 7);
script4('..\data\green_swatch\', 'pixels1', .005, .90, 3.0, 0.05, 6);
script4('..\data\pink_swatch\', 'pixels1', .005, .90, 4.0, 0.05, 6);
script4('..\data\orange_ball\', 'pixels3', .005, .90, 1.0, 0.05, 6);
script4('..\data\orange_ball2\', 'pixels3', .005, .90, 2.5, 0.05, 6);
script4('..\data\green_ball\', 'pixels2', .005, .90, 1.7, 0.05, 6);


script8('..\data\green_ball\', 'pixels1', 5, .90, 1.7, 0.05, 6);
script8('..\data\blue_ball\', 'pixels1', 5, .90, 1.7, 0.05, 6);
script8('..\data\hand\', 'pixels1', 5, .90, 1.7, 0.2, 6);
script8('..\data\pink_swatch\', 'pixels1', 5, .90, 4.0, .1, 6);
script8('..\data\orange_ball\', 'pixels3', 5, .90, .5, .1, 6);
script8('..\data\orange_ball2\', 'pixels1', 5, .90, 1.5, .1, 6);
script8('..\data\green_swatch\', 'pixels1', 5, .90, 4.0, .1, 6);