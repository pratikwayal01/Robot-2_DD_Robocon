function plotlut(LX, LY, LUT)
hold on;

plot(LX(1:2), LY(1:2), '-');
plot(LX(3:4), LY(3:4), '-');
plot(LX(5:6), LY(5:6), '-');
plot(LX(7:8), LY(7:8), '-');
