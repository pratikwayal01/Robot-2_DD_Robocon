#ifndef __DCT_H__
#define __DCT_H__

// integer DCTs
void dct(short pixel[8][8], short data[8][8]);

#endif//__DCT_H__
